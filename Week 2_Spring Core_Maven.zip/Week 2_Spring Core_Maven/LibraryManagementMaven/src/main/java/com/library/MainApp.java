package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library.service.BookService;

public class MainApp {
    public static void main(String[] args) {
//    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//
//        // Retrieve BookService bean
//        BookService bookService = (BookService) context.getBean("bookService");
//
//        // Test the BookService instance
//        if (bookService != null) {
//            System.out.println("BookService bean successfully created and injected.");
//        } else {
//            System.out.println("Failed to create BookService bean.");
//        }
    	 ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

         // Retrieve BookService bean
         BookService bookService = (BookService) context.getBean("bookService");

      // Call the method to trigger the aspect
         bookService.performAction();

         // Ensure the application is running correctly
         System.out.println("LibraryManagementApplication running.");
    }
}
