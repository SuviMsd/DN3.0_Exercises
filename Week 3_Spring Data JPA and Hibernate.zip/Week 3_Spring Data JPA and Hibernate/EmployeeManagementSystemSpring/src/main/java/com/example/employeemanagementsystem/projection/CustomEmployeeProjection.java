
package com.example.employeemanagementsystem.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomEmployeeProjection {
    @Value("#{target.name + ' (' + target.email + ')'}")
    String getCustomName();
}
