package com.example.employeemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.example.employeemanagementsystem.model")


public class EmployeeManagementSystemSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemSpringApplication.class, args);
	}

}
