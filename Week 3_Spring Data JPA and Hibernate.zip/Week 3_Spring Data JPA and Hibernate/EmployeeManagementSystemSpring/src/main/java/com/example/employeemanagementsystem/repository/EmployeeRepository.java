
package com.example.employeemanagementsystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.projection.CustomEmployeeProjection;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<CustomEmployeeProjection> findCustomEmployeeProjectionsByDepartmentName(String departmentName);
}
