
public class Main {
    public static void main(String[] args) {
        // Initialize the employee management system with capacity for 5 employees
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        // Add employees
        system.addEmployee(new Employee("E001", "John Doe", "Developer", 80000));
        system.addEmployee(new Employee("E002", "Jane Smith", "Manager", 90000));
        system.addEmployee(new Employee("E003", "Emily Davis", "Analyst", 75000));

        // Display all employees
        System.out.println("All Employees:");
        system.traverseEmployees();

        // Search for an employee by ID
        System.out.println("\nSearching for employee with ID E002:");
        Employee employee = system.searchEmployeeById("E002");
        System.out.println(employee != null ? employee : "Employee not found");

        // Delete an employee
        System.out.println("\nDeleting employee with ID E003:");
        system.deleteEmployeeById("E003");

        // Display all employees after deletion
        System.out.println("\nAll Employees after deletion:");
        system.traverseEmployees();
    }
}
