
public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        // Mock implementation for demonstration purposes
        // In a real application, this would interact with a database or another data source
        return new Customer(id, "John Doe", "john.doe@example.com");
    }
}
