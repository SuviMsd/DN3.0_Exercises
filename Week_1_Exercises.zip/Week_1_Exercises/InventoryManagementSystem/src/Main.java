
public class Main {
    public static void main(String[] args) {
        // Create an InventoryManager
        InventoryManager inventoryManager = new InventoryManager();

        // Create and add products
        Product p1 = new Product("P001", "Laptop", 10, 999.99);
        Product p2 = new Product("P002", "Smartphone", 25, 499.99);

        inventoryManager.addProduct(p1);
        inventoryManager.addProduct(p2);

        // Display all products
        System.out.println("All products:");
        inventoryManager.displayAllProducts();

        // Update a product
        Product updatedP1 = new Product("P001", "Laptop", 8, 899.99);
        inventoryManager.updateProduct("P001", updatedP1);

        // Display all products after update
        System.out.println("\nAll products after update:");
        inventoryManager.displayAllProducts();

        // Delete a product
        inventoryManager.deleteProduct("P002");

        // Display all products after deletion
        System.out.println("\nAll products after deletion:");
        inventoryManager.displayAllProducts();
    }
}
