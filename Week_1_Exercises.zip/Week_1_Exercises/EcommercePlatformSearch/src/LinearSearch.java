
public class LinearSearch {
    public static Product search(Product[] products, String searchTerm) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(searchTerm) ||
                product.getProductId().equalsIgnoreCase(searchTerm)) {
                return product;
            }
        }
        return null; // Product not found
    }
}
