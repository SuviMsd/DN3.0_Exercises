
public class Main {
    public static void main(String[] args) {
        // Create an array of products
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Coffee Maker", "Appliances"),
            new Product("P004", "Blender", "Appliances")
        };

        // Linear Search
        System.out.println("Linear Search:");
        Product linearResult = LinearSearch.search(products, "Smartphone");
        System.out.println(linearResult != null ? linearResult : "Product not found");

        // Sort products by name for binary search
        BinarySearch.sortByName(products);

        // Binary Search
        System.out.println("\nBinary Search:");
        Product binaryResult = BinarySearch.search(products, "Blender");
        System.out.println(binaryResult != null ? binaryResult : "Product not found");
    }
}
