
import java.util.Arrays;

public class BinarySearch {
    public static Product search(Product[] products, String searchTerm) {
        int low = 0;
        int high = products.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            Product midProduct = products[mid];

            int cmp = midProduct.getProductName().compareToIgnoreCase(searchTerm);

            if (cmp == 0) {
                return midProduct;
            } else if (cmp < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // Product not found
    }

    // Method to sort the products by name before performing binary search
    public static void sortByName(Product[] products) {
        Arrays.sort(products, (a, b) -> a.getProductName().compareToIgnoreCase(b.getProductName()));
    }
}
