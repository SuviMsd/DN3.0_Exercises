
public class TestComputerBuilder {
    public static void main(String[] args) {
        // Create different configurations of Computer using the Builder pattern

        // High-end gaming computer
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGPU("NVIDIA RTX 3090")
                .setPowerSupply("750W")
                .setMotherboard("ASUS ROG")
                .build();

        System.out.println("Gaming Computer: " + gamingComputer);

        // Office computer
        Computer officeComputer = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("16GB")
                .setStorage("512GB SSD")
                .setPowerSupply("500W")
                .setMotherboard("Gigabyte B450")
                .build();

        System.out.println("Office Computer: " + officeComputer);

        // Budget computer
        Computer budgetComputer = new Computer.Builder()
                .setCPU("AMD Ryzen 3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .setPowerSupply("400W")
                .setMotherboard("MSI A320")
                .build();

        System.out.println("Budget Computer: " + budgetComputer);
    }
}

