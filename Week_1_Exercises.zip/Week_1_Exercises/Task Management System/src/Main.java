
public class Main {
    public static void main(String[] args) {
        // Initialize the task management system
        SinglyLinkedList taskList = new SinglyLinkedList();

        // Add tasks
        taskList.addTask(new Task("T001", "Complete project report", "Pending"));
        taskList.addTask(new Task("T002", "Prepare presentation slides", "In Progress"));
        taskList.addTask(new Task("T003", "Send project email", "Completed"));

        // Display all tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Search for a task by ID
        System.out.println("\nSearching for task with ID T002:");
        Task task = taskList.searchTaskById("T002");
        System.out.println(task != null ? task : "Task not found");

        // Delete a task
        System.out.println("\nDeleting task with ID T003:");
        taskList.deleteTaskById("T003");

        // Display all tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        taskList.traverseTasks();
    }
}
