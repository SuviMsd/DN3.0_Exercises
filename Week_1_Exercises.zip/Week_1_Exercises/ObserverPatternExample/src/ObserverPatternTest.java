public class ObserverPatternTest {
    public static void main(String[] args) {
    	StockMarket stockMarket = new StockMarket();

        // Create observers
        MobileApp mobileApp = new MobileApp();
        WebApp webApp = new WebApp();

        // Register observers with the stock market
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Change stock price and notify observers
        stockMarket.setStockPrice(100.50);
        stockMarket.setStockPrice(105.75);
        
        // Deregister an observer and change stock price again
        stockMarket.deregisterObserver(mobileApp);
        stockMarket.setStockPrice(110.00);
    }
}
