// WebApp.java
public class WebApp implements Observer {
    private double stockPrice;

    public WebApp() {
		// TODO Auto-generated constructor stub
	}


	@Override
    public void update(double stockPrice) {
        this.stockPrice = stockPrice;
        display();
    }

    private void display() {
        System.out.println("Web App - Stock Price updated to: $" + stockPrice);
    }
}
