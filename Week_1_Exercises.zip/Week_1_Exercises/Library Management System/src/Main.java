
public class Main {
    public static void main(String[] args) {
        // Initialize the library management system
        LibraryManagementSystem library = new LibraryManagementSystem();

        // Add books
        library.addBook(new Book("B001", "Effective Java", "Joshua Bloch"));
        library.addBook(new Book("B002", "Clean Code", "Robert C. Martin"));
        library.addBook(new Book("B003", "Introduction to Algorithms", "Thomas H. Cormen"));

        // Search for a book using linear search
        System.out.println("Searching for 'Clean Code' using Linear Search:");
        Book book = library.searchByTitleLinear("Clean Code");
        System.out.println(book != null ? book : "Book not found");

        // Search for a book using binary search
        System.out.println("\nSearching for 'Effective Java' using Binary Search:");
        book = library.searchByTitleBinary("Effective Java");
        System.out.println(book != null ? book : "Book not found");
    }
}
