// Main.java
public class Main {
    public static void main(String[] args) {
        // Create an array of orders
        Order[] orders = {
            new Order("O001", "Alice", 150.50),
            new Order("O002", "Bob", 75.00),
            new Order("O003", "Charlie", 200.00),
            new Order("O004", "Diana", 120.00)
        };

        // Bubble Sort
        System.out.println("Bubble Sort:");
        BubbleSort.sort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Reinitialize array for Quick Sort
        orders = new Order[] {
            new Order("O001", "Alice", 150.50),
            new Order("O002", "Bob", 75.00),
            new Order("O003", "Charlie", 200.00),
            new Order("O004", "Diana", 120.00)
        };

        // Quick Sort
        System.out.println("\nQuick Sort:");
        QuickSort.sort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}

