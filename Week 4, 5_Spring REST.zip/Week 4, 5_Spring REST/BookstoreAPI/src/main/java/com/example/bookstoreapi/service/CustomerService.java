package com.example.bookstoreapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookstoreapi.model.Customer;
import com.example.bookstoreapi.repository.CustomerRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // Method to update a customer
    public Customer updateCustomer(Long id, Customer customerDetails) {
        // Retrieve the existing customer by ID
        Optional<Customer> optionalCustomer = customerRepository.findById(id);

        if (optionalCustomer.isPresent()) {
            Customer existingCustomer = optionalCustomer.get();
            
            // Update the customer details
            existingCustomer.setName(customerDetails.getName());
            existingCustomer.setEmail(customerDetails.getEmail());
            existingCustomer.setAddress(customerDetails.getAddress());
            // Update other fields as necessary

            // Save the updated customer back to the repository
            return customerRepository.save(existingCustomer);
        } else {
            // Handle the case where the customer is not found
            throw new RuntimeException("Customer not found with id: " + id);
        }
    }
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
    public void deleteCustomer(Long id) {
        if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);
        } else {
            throw new RuntimeException("Customer not found with id: " + id);
        }
    }
    public Customer getCustomerById(Long id) {
        Optional<Customer> customer = customerRepository.findById(id);
        if (customer.isPresent()) {
            return customer.get();
        } else {
            throw new RuntimeException("Customer not found with id: " + id);
        }
    }
    public Customer createCustomer(Customer customer) {
        // Perform any additional business logic if needed
        return customerRepository.save(customer);
    }
}
