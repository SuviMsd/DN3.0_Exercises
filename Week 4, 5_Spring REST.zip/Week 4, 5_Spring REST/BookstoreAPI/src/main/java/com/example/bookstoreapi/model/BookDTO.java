package com.example.bookstoreapi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class BookDTO {
    private Long id;
    private String title;
    private String author;
    private Double price;

    @JsonIgnore
    private String isbn;  // This field will be ignored during serialization
}
