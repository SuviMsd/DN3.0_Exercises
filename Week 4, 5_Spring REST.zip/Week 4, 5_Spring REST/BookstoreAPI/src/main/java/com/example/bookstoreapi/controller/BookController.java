////package com.example.bookstoreapi.controller;
////
////import java.util.ArrayList;
////import java.util.List;
////import java.util.Optional;
////import java.util.stream.Collectors;
////
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.PathVariable;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RequestParam;
////import org.springframework.web.bind.annotation.RestController;
////
////import com.example.bookstoreapi.model.Book;
////
////@RestController
////@RequestMapping("/books")
////public class BookController {
////
////    private List<Book> books = new ArrayList<>();
////
////    public BookController() {
////        books.add(new Book(1L, "1984", "George Orwell", 9.99, "9780451524935"));
////        books.add(new Book(2L, "To Kill a Mockingbird", "Harper Lee", 7.99, "9780061120084"));
////    }
////
////    // Endpoint to fetch a book by ID using a path variable
////    @GetMapping("/{id}")
////    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
////        Optional<Book> book = books.stream()
////                                   .filter(b -> b.getId().equals(id))
////                                   .findFirst();
////        return book.map(ResponseEntity::ok)
////                   .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
////    }
////
////    // Endpoint to filter books based on query parameters (title and author)
////    @GetMapping
////    public ResponseEntity<List<Book>> getBooksByQuery(
////            @RequestParam(required = false) String title,
////            @RequestParam(required = false) String author) {
////
////        List<Book> filteredBooks = books.stream()
////                .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)))
////                .filter(book -> (author == null || book.getAuthor().equalsIgnoreCase(author)))
////                .collect(Collectors.toList());
////
////        return ResponseEntity.ok(filteredBooks);
////    }
////}
////package com.example.bookstoreapi.controller;
////
////import java.util.ArrayList;
////import java.util.List;
////import java.util.Optional;
////
////import org.springframework.http.HttpHeaders;
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.PathVariable;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RestController;
////
////import com.example.bookstoreapi.model.Book;
////
////@RestController
////@RequestMapping("/books")
////public class BookController {
////
////    private List<Book> books = new ArrayList<>();
////
////    public BookController() {
////        books.add(new Book(1L, "1984", "George Orwell", 9.99, "9780451524935"));
////        books.add(new Book(2L, "To Kill a Mockingbird", "Harper Lee", 7.99, "9780061120084"));
////    }
////
////    // GET: Retrieve a book by ID with custom headers
////    @GetMapping("/{id}")
////    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
////        Optional<Book> book = books.stream()
////                                   .filter(b -> b.getId().equals(id))
////                                   .findFirst();
////
////        if (book.isPresent()) {
////            HttpHeaders headers = new HttpHeaders();
////            headers.add("X-Custom-Header", "CustomHeaderValue");
////            return new ResponseEntity<>(book.get(), headers, HttpStatus.OK);
////        } else {
////            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
////        }
////    }
////}
////
////package com.example.bookstoreapi.controller;
////
////import java.util.ArrayList;
////import java.util.List;
////import java.util.Optional;
////
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.PathVariable;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RestController;
////
////import com.example.bookstoreapi.exception.BookNotFoundException;
////import com.example.bookstoreapi.model.Book;
////
////@RestController
////@RequestMapping("/books")
////public class BookController {
////
////    private List<Book> books = new ArrayList<>();
////
////    public BookController() {
////        books.add(new Book(1L, "1984", "George Orwell", 9.99, "9780451524935"));
////        books.add(new Book(2L, "To Kill a Mockingbird", "Harper Lee", 7.99, "9780061120084"));
////    }
////
////    // GET: Retrieve a book by ID with custom exception handling
////    @GetMapping("/{id}")
////    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
////        Optional<Book> book = books.stream()
////                                   .filter(b -> b.getId().equals(id))
////                                   .findFirst();
////
////        if (book.isPresent()) {
////            return new ResponseEntity<>(book.get(), HttpStatus.OK);
////        } else {
////            throw new BookNotFoundException(id);
////        }
////    }
////}
//package com.example.bookstoreapi.controller;
//
//import java.util.List;
//
//import javax.validation.Valid;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.bookstoreapi.model.Book;
//import com.example.bookstoreapi.service.BookService;
//
//@RestController
//@RequestMapping("/books")
//public class BookController {
//
//    private final BookService bookService;
//
//    public BookController(BookService bookService) {
//        this.bookService = bookService;
//    }
//
//    // CREATE a new book
//    @PostMapping
//    public ResponseEntity<Book> createBook(@Valid @RequestBody Book book) {
//        Book savedBook = bookService.createBook(book);
//        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
//    }
//
//    // READ all books
//    @GetMapping
//    public List<Book> getAllBooks() {
//        return bookService.getAllBooks();
//    }
//
//    // READ a single book by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
//        Book book = bookService.getBookById(id);
//        return ResponseEntity.ok(book);
//    }
//
//    // UPDATE a book
//    @PutMapping("/{id}")
//    public ResponseEntity<Book> updateBook(@PathVariable Long id, @Valid @RequestBody Book bookDetails) {
//        Book updatedBook = bookService.updateBook(id, bookDetails);
//        return ResponseEntity.ok(updatedBook);
//    }
//
//    // DELETE a book
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
//        bookService.deleteBook(id);
//        return ResponseEntity.noContent().build();
//    }
//}
package com.example.bookstoreapi.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bookstoreapi.assembler.BookResourceAssembler;
import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.service.BookService;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookResourceAssembler bookResourceAssembler;

    @GetMapping
    public List<EntityModel<Book>> getAllBooks() {
        return bookService.getAllBooks().stream()
                .map(bookResourceAssembler::toModel)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public EntityModel<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id);
        return bookResourceAssembler.toModel(book);
    }

    // Other CRUD endpoints
}
