package com.example.bookstoreapi.metrics;

import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.MeterBinder;

@Component
public class CustomMetrics implements MeterBinder {

    @Override
    public void bindTo(MeterRegistry registry) {
        // Example: Custom gauge
        registry.gauge("custom.gauge", 100);

        // Example: Custom counter
        registry.counter("custom.counter", "type", "example");
    }
}
