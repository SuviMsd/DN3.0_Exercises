////package com.example.bookstoreapi.controller;
////
////import java.util.ArrayList;
////import java.util.List;
////
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.PostMapping;
////import org.springframework.web.bind.annotation.RequestBody;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RequestParam;
////import org.springframework.web.bind.annotation.RestController;
////
////import com.example.bookstoreapi.model.Customer;
////
////@RestController
////@RequestMapping("/customers")
////public class CustomerController {
////
////    private List<Customer> customers = new ArrayList<>();
////
////    @PostMapping("/register")
////    public ResponseEntity<Customer> registerCustomer(@RequestBody Customer customer) {
////        customers.add(customer);
////        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
////    }
////
////    // POST: Register a new customer with form data
////    @PostMapping(value = "/register-form", consumes = "application/x-www-form-urlencoded")
////    public ResponseEntity<Customer> registerCustomerFromForm(
////            @RequestParam String name,
////            @RequestParam String email,
////            @RequestParam String password) {
////
////        Customer customer = new Customer();
////        customer.setId((long) (customers.size() + 1));  // Simple ID generation
////        customer.setName(name);
////        customer.setEmail(email);
////        customer.setPassword(password);
////
////        customers.add(customer);
////        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
////    }
////}
//package com.example.bookstoreapi.controller;
//
//import java.util.List;
//
//import javax.validation.Valid;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.bookstoreapi.model.Customer;
//import com.example.bookstoreapi.service.CustomerService;
//
//@RestController
//@RequestMapping("/customers")
//public class CustomerController {
//
//    private final CustomerService customerService;
//
//    public CustomerController(CustomerService customerService) {
//        this.customerService = customerService;
//    }
//
//    // CREATE a new customer
//    @PostMapping
//    public ResponseEntity<Customer> createCustomer(@Valid @RequestBody Customer customer) {
//        Customer savedCustomer = customerService.createCustomer(customer);
//        return new ResponseEntity<>(savedCustomer, HttpStatus.CREATED);
//    }
//
//    // READ all customers
//    @GetMapping
//    public List<Customer> getAllCustomers() {
//        return customerService.getAllCustomers();
//    }
//
//    // READ a single customer by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
//        Customer customer = customerService.getCustomerById(id);
//        return ResponseEntity.ok(customer);
//    }
//
//    // UPDATE a customer
//    @PutMapping("/{id}")
//    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @Valid @RequestBody Customer customerDetails) {
//        Customer updatedCustomer = customerService.updateCustomer(id, customerDetails);
//        return ResponseEntity.ok(updatedCustomer);
//    }
//
//    // DELETE a customer
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
//        customerService.deleteCustomer(id);
//        return ResponseEntity.noContent().build();
//    }
//}
package com.example.bookstoreapi.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bookstoreapi.assembler.CustomerResourceAssembler;
import com.example.bookstoreapi.model.Customer;
import com.example.bookstoreapi.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private CustomerResourceAssembler customerResourceAssembler;

    @GetMapping
    public List<EntityModel<Customer>> getAllCustomers() {
        return customerService.getAllCustomers().stream()
                .map(customerResourceAssembler::toModel)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public EntityModel<Customer> getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        return customerResourceAssembler.toModel(customer);
    }

    @PostMapping
    public EntityModel<Customer> createCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = customerService.createCustomer(customer);
        return customerResourceAssembler.toModel(createdCustomer);
    }

    // Other CRUD endpoints
}
